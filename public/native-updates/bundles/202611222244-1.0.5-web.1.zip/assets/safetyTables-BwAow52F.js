import{s as n}from"./index-_9ExI_KR.js";function e(t){return n.from(t)}export{e as f};
