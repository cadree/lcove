import{b4 as n}from"./index-_9ExI_KR.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
