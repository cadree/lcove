import{cl as n}from"./index-DX0aWaS3.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
