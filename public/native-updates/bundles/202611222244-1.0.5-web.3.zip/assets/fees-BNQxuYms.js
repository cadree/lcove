const E=10,_=10;export{_ as C,E as S};
