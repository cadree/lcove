function T(o,r,i){return new Promise((s,t)=>{const n=setTimeout(()=>{t(new Error(i))},r);o.then(e=>{clearTimeout(n),s(e)},e=>{clearTimeout(n),t(e)})})}const a=12e3;export{a as L,T as w};
