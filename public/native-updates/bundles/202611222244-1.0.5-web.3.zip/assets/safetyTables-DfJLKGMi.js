import{s as n}from"./index-DX0aWaS3.js";function e(t){return n.from(t)}export{e as f};
