const E="Cinema",A="My network";export{A as C,E as a};
