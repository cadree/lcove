const f={profileBlogs:!1,profileSavedTab:!1,profileFilmForm:!1,exampleContent:!1};function a(e){return f[e]}export{a as f};
