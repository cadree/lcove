import{t as o}from"./en-US-CulqtCeB.js";function r(t){return+o(t)<Date.now()}export{r as i};
