function i(e){e.invalidateQueries({queryKey:["novi-board"]}),e.invalidateQueries({queryKey:["my-xp"]})}export{i as r};
