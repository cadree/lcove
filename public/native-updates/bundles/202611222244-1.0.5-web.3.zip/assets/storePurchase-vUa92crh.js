function s(e,r){return r||e.is_digital!==!0&&(e.type==="rental"||e.is_digital===!1)}export{s};
