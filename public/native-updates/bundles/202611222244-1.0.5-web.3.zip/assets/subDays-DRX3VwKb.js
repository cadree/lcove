import{a as r}from"./addDays-Bok_Rf8F.js";function t(a,s){return r(a,-s)}export{t as s};
