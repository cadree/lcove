import{a as o}from"./addDays-Bok_Rf8F.js";function t(a,s){const d=s*7;return o(a,d)}export{t as a};
