import{j as e}from"./vendor-DPUYNzeb.js";function r(){return e.jsx("p",{className:"py-6 text-center text-[11px] text-muted-foreground",children:"Powered by Ether"})}export{r as P};
