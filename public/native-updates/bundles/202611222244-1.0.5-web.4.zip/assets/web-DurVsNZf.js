import{cm as n}from"./index-DdaX1A8D.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
