import{k as i,bL as f,ap as u,bM as d,bN as p}from"./index-DdaX1A8D.js";import{r as n}from"./vendor-DPUYNzeb.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=i("Crown",[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]]),o=f("EtherStorefront");async function y(){var t;if(!u())return null;try{const e=((t=(await o.getCountryCode()).countryCode)==null?void 0:t.trim())??"";return e||null}catch{return null}}async function k(t){if(!d(t))throw new Error("Checkout link isn't allowed.");await o.openExternal({url:t})}async function E(t){await o.openExternal({url:t})}function x(){const t=u(),[r,e]=n.useState(null),[a,c]=n.useState(!t);return n.useEffect(()=>{if(!t)return;let s=!1;return y().then(l=>{s||(e(l),c(!0))}),()=>{s=!0}},[t]),{ios:t,ready:a,country:r,linkOut:t&&a&&p(r)}}export{w as C,k as a,E as o,y as r,x as u};
