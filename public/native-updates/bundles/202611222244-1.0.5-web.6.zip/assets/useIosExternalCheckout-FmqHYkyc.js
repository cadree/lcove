import{k as c,ap as i,bN as f}from"./index-DoSd7n4e.js";import{r as e}from"./vendor-DPUYNzeb.js";import{r as l}from"./externalCheckout-DK6eNGd7.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=c("Crown",[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]]);function C(){const t=i(),[r,s]=e.useState(null),[a,n]=e.useState(!t);return e.useEffect(()=>{if(!t)return;let o=!1;return l().then(u=>{o||(s(u),n(!0))}),()=>{o=!0}},[t]),{ios:t,ready:a,country:r,linkOut:t&&a&&f(r)}}export{m as C,C as u};
