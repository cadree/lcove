import{cm as n}from"./index-DoSd7n4e.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
