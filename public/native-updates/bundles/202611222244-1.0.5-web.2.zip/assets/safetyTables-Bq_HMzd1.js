import{s as n}from"./index-CESknvcj.js";function e(t){return n.from(t)}export{e as f};
