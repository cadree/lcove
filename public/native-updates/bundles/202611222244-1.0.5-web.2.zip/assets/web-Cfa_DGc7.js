import{cl as n}from"./index-CESknvcj.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
